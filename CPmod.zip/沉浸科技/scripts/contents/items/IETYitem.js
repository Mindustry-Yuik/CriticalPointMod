function newItem(name, color, obj) {
	Object.assign(exports[name] = new Item(name,
		Color.valueOf(color)), obj);
}
function newLiquid(name, color, obj) {
	Object.assign(exports[name] = new Liquid(name,
		Color.valueOf(color)), obj);
}
//安山
newItem("安山矿", "484A52FF", {
	cost: 2,
})
newItem("安山矿板", "484A52FF", {
	cost: 4,
})
newItem("安山合金", "484A52FF", {
	cost: 6,
})

//酮
newItem("酮体", "9DEC85FF", {
	cost: 1,
})
newItem("酮凝胶", "9DEC85FF", {
	cost: 1,
})
newItem("聚酮脂", "9DEC85FF", {
	cost: 1,
	radioactivity: 0.185, //放射性
})

//绯樱石英
newItem("绯樱石英矿", "F786B0FF", {
	cost: 3,
	flammability: 1.255, //燃烧性
})
newItem("绯樱石英块", "F786B0FF", {
	cost: 5,
	flammability: 1.5, //燃烧性
})
//碳
/*
煤 -> 石墨 -> (酮体+安山矿板)碳 -> [提纯炉] -> 碳板 -> 碳素
*/
newItem("碳", "3D414CFF", {
	cost: 7,
	flammability: 1, //燃烧性
})
newItem("碳板", "3D414CFF", {
	cost: 9,
	flammability: 1.55, //燃烧性
})
newItem("碳素", "3D414CFF", {
	cost: 12,
	flammability: 2.85, //燃烧性
	explosiveness: 0.05, //爆炸性
})


//此乃注释也
	/*
	hardness: 0, //硬度，只有矿物有，与挖掘速度、挖掘等级有关
	radioactivity: 0, //放射性
	explosiveness: 1, //爆炸性
	flammability: 0, //燃烧性
	charge: 1.5, //放电性
	cost: 1.5, //建筑时间消耗倍率
	frames: 10,//动态贴图帧数
	*/