const item = require('contents/items/IETYitem');

const 碳板传送带 = new Conveyor("碳板传送带");
exports.碳板传送带 = 碳板传送带;
碳板传送带.researchCostMultiplier = 0.5;
Object.assign(碳板传送带, {
	buildVisibility: BuildVisibility.shown,
	category: Category.distribution,
	requirements: ItemStack.with(
		item.碳板, 2,
	),
	health: 180,
	speed: 0.1,
	displayedSpeed: 12,
});

const 安山传送带 = new Conveyor("安山传送带");
exports.安山传送带 = 安山传送带;
安山传送带.researchCostMultiplier = 0.5;
Object.assign(安山传送带, {
	buildVisibility: BuildVisibility.shown,
	category: Category.distribution,
	requirements: ItemStack.with(
		item.安山矿板, 2,
	),
	health: 70,
	speed: 0.048,
	displayedSpeed: 6.5,
});
