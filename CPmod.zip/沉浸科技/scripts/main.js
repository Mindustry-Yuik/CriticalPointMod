//星球 | planet
require("lk")
require("planet/西弗兰卡")

require("contents/items/IETYitem")
require("contents/Blocks/conveyors")
// 定义输入和输出物品
