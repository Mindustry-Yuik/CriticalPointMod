function createScanButton(text, width, height, scanColor) {
    const button = new Button(Styles.cleart);
    button.scanAnimation = false;    // 设置按钮文本
    button.add(new Label(text));    // 设置按钮大小
    button.setSize(width, height);    // 添加悬停事件监听器
    button.addListener(new InputListener({
        enter(event, x, y, pointer, fromActor) {
            button.scanAnimation = true;
        },
        exit(event, x, y, pointer, toActor) {
            button.scanAnimation = false;
        }
    }));
    // 绘制扫描效果
    const drawScanEffect = (button) => {
        const width = button.getWidth();
        const height = button.getHeight();
        const x = button.getX();
        const y = button.getY();

        const scanWidth = 20; // 扫描线宽度
        const scanSpeed = 2;  // 扫描速度
        const scanX = (Time.time * scanSpeed) % (width + scanWidth) - scanWidth;

        Draw.color(scanColor || Color.valueOf("ffffff")); // 使用传入的颜色，默认为白色
        Draw.alpha(0.5); // 设置透明度
        Draw.rect("white", x + scanX, y, scanWidth, height); // 绘制扫描线
        Draw.reset(); // 重置颜色和透明度
    };
    // 重写按钮的 draw 方法
    button.draw = () => {
        this.super$draw(); // 调用父类的 draw 方法
        if (button.scanAnimation) {
            drawScanEffect(button); // 绘制扫描效果
        }
    };
    return button;
}