exports.modName = "iety";
exports.mod = Vars.mods.locateMod(exports.modName);
exports.getMessage = function(type, key) {
    return Core.bundle.get(type + "." + exports.modName + "." + key);
}

exports.maxDamage = Stat("maxDamage");
exports.regenAmount = Stat("regenAmount");
exports.damageReduction = Stat("damageReduction");

exports.addResearch = (content, research) => {
	if (!content) {
		throw new Error('content is null!');
	}
	if (!research.parent) {
		throw new Error('research.parent is empty!');
	}
	let researchName = research.parent;
	let customRequirements = research.requirements;
	let objectives = research.objectives;
	let lastNode = TechTree.all.find(boolf(t => t.content == content));
	if (lastNode != null) {
		lastNode.remove();
	}
	let node = new TechTree.TechNode(null, content, customRequirements !== undefined ? customRequirements : content.researchRequirements());
	if (objectives) {
		node.objectives.addAll(objectives);
	}
	if (node.parent != null) {
		node.parent.children.remove(node);
	}
	// find parent node.
	let parent = TechTree.all.find(boolf(t => t.content.name.equals(researchName) || t.content.name.equals(exports.modName + "-" + researchName)));
	if (parent == null) {
		throw new Error("Content '" + researchName + "' isn't in the tech tree, but '" + content.name + "' requires it to be researched.");
	}
	// add this node to the parent
	if (!parent.children.contains(node)) {
		parent.children.add(node);
	}
	// reparent the node
	node.parent = parent;
}

exports.newBlock = (name, con) => {
	const b = extend(Block, name, con || {});
	b.solid/*方块*/ = b.update/*实时更新*/ = b.hasItems/*是否能接受物品*/ = b.destructible/*可破坏的*/ = b.configurable/*可配置的？*/ = true
	b.envEnabled = Env.any;
	b.group = BlockGroup.none;
	b.priority = TargetPriority.base;
	b.category = Category.effect;
	b.buildVisibility = BuildVisibility.shown;
	return b
}


exports.setBuilding = (building, block, con) => {
	block.buildType = prov(() => {
		if (building == Building) {
			return extend(building, con);
		} else {
			return extend(building, block, con);
		}
	})
}

exports.region = (name) => {
	return Core.atlas.find(exports.modName + "-" + name);
}

exports.bundle = (text, num, num1) => {
	if (num1) {
		return Core.bundle.format(text, num, num1);
	} else if (num) {
		return Core.bundle.format(text, num);
	} else {
		return Core.bundle.get(text);
	}
}

exports.Coolant = (block, v, num) => {
	block.coolant = block.consumeCoolant(v);
	if (num) block.coolantMultiplier = num;
}

exports.limitBuild = (block, num) => {
	return block.localizedName + exports.bundle("text-limitBuild", num);
}

exports.float = (speed, length, slow) => {
	if (slow) return Mathf.sin(Time.time * speed) * length;
	return Mathf.absin(Time.time, speed, length);
}

exports.Color = (R, G, B, A) => {
	if (G) return new Color(R, G, B, A || 1);
	else return Color.valueOf(R);
}

exports.FF5845 = exports.Color("FF5845");
exports.FF6666 = exports.Color("FF6666");
exports.FF8663 = exports.Color("FF8663");
exports.FEB380 = exports.Color("FEB380");
exports.FFD37FFF = exports.Color("FFD37FFF");
//紫色
//exports.8477DDFF = exports.Color("8477DDFF");
exports.B5AAFFFF = exports.Color("B5AAFFFF");
//绿色
//exports.97FF91FF = exports.Color("97FF91FF");

exports.Randonge = (rx, ry, range) => {
	return {
		x: Mathf.range(range) + rx,
		y: Mathf.range(range) + ry
	}
}

exports.AngleTrns = (ang, rad, rad2) => {
	if (rad2) {
		return {
			x: Angles.trnsx(ang, rad, rad2),
			y: Angles.trnsy(ang, rad, rad2)
		}
	} else {
		return {
			x: Angles.trnsx(ang, rad),
			y: Angles.trnsy(ang, rad)
		}
	}
}

exports.DoubleTri = (x, y, width, length, angle, len) => {
	Draw.z(Layer.effect);
	Drawf.tri(x, y, width, length, angle + 180);
	Drawf.tri(x, y, width, length / (len || 4), angle);
}
exports.OnecTri = (x, y, width, length, angle, len) => {
	Draw.z(Layer.effect);
	Drawf.tri(x, y, width, length, angle + 180);
	//Drawf.tri(x, y, width, length / (len || 4), angle);
}


exports.Halo = (obj) => {
	let def = {
		progress: DrawPart.PartProgress.warmup,
		mirror: true,
		x: 0,
		y: 0,
		moveX: 0,
		moveY: 0,
		shapeMR: 0,
		shapeR: 0,
		shapes: 2,
		radius: 4,
		radiusTo: -1,
		triL: 1,
		triLT: -1,
		haloRad: 0,
		haloRadTo: -1,
		haloRot: 0,
		haloRS: 0,
		color: exports.FF5845,
		colorTo: exports.FF8663
	}
	for (let k in def) {
		if (obj[k] == undefined) continue
		def[k] = obj[k]
	}
	return Object.assign(new HaloPart, {
		progress: def.progress,
		mirror: def.mirror,
		tri: true,
		x: def.x,
		y: def.y,
		moveX: def.moveX,
		moveY: def.moveY,
		shapeMoveRot: def.shapeMR,
		shapeRotation: def.shapeR,
		shapes: def.shapes,
		radius: def.radius,
		radiusTo: def.radiusTo,
		triLength: def.triL,
		triLengthTo: def.triLT,
		haloRadius: def.haloRad,
		haloRadiusTo: def.haloRadTo,
		haloRotation: def.haloRot,
		haloRotateSpeed: def.haloRS,
		color: def.color,
		colorTo: def.colorTo,
		layer: 110
	})
}

exports.DoubleHalo = (e, obj, num) => {
	if (!num) num = 4;
	e.parts.add(
		exports.Halo({
			progress: obj.progress,
			mirror: obj.mirror,
			x: obj.x,
			y: obj.y,
			moveX: obj.moveX,
			moveY: obj.moveY,
			shapeMR: obj.shapeMR,
			shapes: obj.shapes,
			radius: obj.radius,
			radiusTo: obj.radiusTo,
			triL: obj.triL,
			triLT: obj.triLT,
			haloRad: obj.haloRad,
			haloRadTo: obj.haloRadTo,
			haloRot: obj.haloRot,
			haloRS: obj.haloRS,
			color: obj.color,
			colorTo: obj.colorTo
		}),
		exports.Halo({
			progress: obj.progress,
			mirror: obj.mirror,
			x: obj.x,
			y: obj.y,
			moveX: obj.moveX,
			moveY: obj.moveY,
			shapeMR: obj.shapeMR,
			shapeR: 180,
			shapes: obj.shapes,
			radius: obj.radius,
			radiusTo: obj.radiusTo,
			triL: obj.triL / num || 1,
			triLT: obj.triLT / num || -1,
			haloRad: obj.haloRad,
			haloRadTo: obj.haloRadTo,
			haloRot: obj.haloRot,
			haloRS: obj.haloRS,
			color: obj.color,
			colorTo: obj.colorTo
		})
	)
}

exports.coolant = (t, amount) => {
	return t.coolant = t.consumeCoolant(amount);
}

exports.limitTurret = (type, name, num) => {
	return extend(type, name, {
		canPlaceOn(tile, team, rotation) {
			return Vars.state.teams.get(team).getCount(this) < num;
		},
		drawPlace(x, y, rotation, valid) {
			this.super$drawPlace(x, y, rotation, valid);
			if (Vars.state.teams.get(Vars.player.team()).getCount(this) < num) return
			this.drawPlaceText(exports.limitBuild(this, num), x, y, valid);
		}
	});
}

exports.SpeedUpTurret = (type, name, obj, min, change, limit) => {
	if (!change) change = 1;
	let b = extend(type, name, {
		setBars() {
			this.super$setBars();
			this.addBar("fastReload", func(e => new Bar(
			prov(() => exports.bundle("bar.fastReload", Strings.fixed(e.getTime() * 100, 0))),
			prov(() => exports.FF5845),
			floatp(() => e.getTime()))));
		},
		canPlaceOn(tile, team, rotation) {
			if (!limit) return this.super$canPlaceOn(tile, team, rotation);
			return Vars.state.teams.get(team).getCount(this) < limit;
		},
		drawPlace(x, y, rotation, valid) {
			this.super$drawPlace(x, y, rotation, valid);
			if (!limit) return
			if (Vars.state.teams.get(Vars.player.team()).getCount(this) < limit) return
			this.drawPlaceText(exports.limitBuild(this, limit), x, y, valid);
		}
	});
	Object.assign(b, obj);
	b.buildType = () => {
		let time = b.reload;
		return extend(PowerTurret.PowerTurretBuild, b, {
			getTime() {
				return (b.reload - time) / (b.reload - min);
			},
			updateTile() {
				this.super$updateTile();
				if (this.timer.get(time)) {
					if (this.isShooting() && Angles.angleDist(this.rotation, this.angleTo(this.targetPos)) < this.block.shootCone && this.warmup() >= this.block.minWarmup) {
						this.bullet(this.peekAmmo(), 0, 0, 0, null);
						if (time > min) time -= change
					} else if (b.reload > time) time += change;
				}
			}
		})
	};
	return b;
}