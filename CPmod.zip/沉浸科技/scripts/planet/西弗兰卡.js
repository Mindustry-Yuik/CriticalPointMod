const lib = require("base/lib");
//const DX = require("content/blocks/environments/environment");

const XFLK = new Planet("西弗兰卡", Planets.sun, 1, 3.3);
XFLK.meshLoader = prov(() => new HexMesh(XFLK, 5));
XFLK.cloudMeshLoader = prov(() => new MultiMesh(
	new HexSkyMesh(XFLK, 2, 0.15, 0.14, 5, lib.Color("6B78DEB6"), 2, 0.42, 1, 0.43),
	new HexSkyMesh(XFLK, 3, 0.6, 0.15, 5, lib.Color("969FDFD3"), 2, 0.42, 1.2, 0.45)
));
XFLK.generator = new SerpuloPlanetGenerator();
XFLK.visible = XFLK.accessible = XFLK.alwaysUnlocked = XFLK.allowLaunchLoadout = true; //可见 在行星菜单内显示 总是解锁 可携带初始物资
XFLK.clearSectorOnLose = false; //重置战败区块
XFLK.bloom = true; //启用Bloom渲染效果
XFLK.allowLaunchToNumbered = false;
XFLK.startSector = 1; //初始区块
XFLK.orbitRadius = 36; //公转半径
XFLK.orbitTime = 180 * 60; //公转一圈时间
XFLK.rotateTime = 60 * 45; //自转一圈时间
/*
XFLK.lightSrcFrom = 0;
XFLK.lightSrcTo = 0.04; //0.1
XFLK.lightDstFrom = 0.01; //0.05
XFLK.lightDstTo = 0.05; //0.15
*/
XFLK.prebuildBase = true; //落地建造
XFLK.launchCapacityMultiplier = 0.5;
XFLK.defaultCore = Blocks.coreNucleus;
XFLK.atmosphereRadIn = 0.03; //进入大气层距离
XFLK.atmosphereRadOut = 0.45; //离开大气层距离
XFLK.atmosphereColor = XFLK.lightColor = Color.valueOf("25C9AB90");
XFLK.iconColor = Color.valueOf("868067FF"); //大气层 发光颜色
XFLK.hiddenItems.addAll(Items.erekirItems).removeAll(Items.serpuloItems);
/*
const map1 = new SectorPreset("a1", XFLK, 0);
map1.difficulty = 3;
map1.addStartingItems = true;
exports.map1 = map1;
*/
